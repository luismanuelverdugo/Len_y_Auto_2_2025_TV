package com.example.tablacontenido.tokens;

public class Cadena extends Token {
    public Cadena(String token, int linea, int columnaInicio, int columnaFinal) {
        super(token, linea, columnaInicio, columnaFinal);
    }

    @Override
    public String getTipo() { return "Cadena";}
}