package com.example.tablacontenido.tokens;

public class Identificador extends Token {
    public Identificador(String token, int linea, int columnaInicio, int columnaFinal) {
        super(token, linea, columnaInicio, columnaFinal);
    }

    @Override
    public String getTipo() { return "Identificador";}
}
