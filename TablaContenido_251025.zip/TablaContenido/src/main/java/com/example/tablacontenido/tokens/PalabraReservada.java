package com.example.tablacontenido.tokens;

public class PalabraReservada extends Token{
    public PalabraReservada (String token, int linea, int columnaInicio, int columnaFinal){
        super(token, linea, columnaInicio, columnaFinal);
    }

    @Override
    public String getTipo(){
        return "Palabra Reservada";
    }


}
