package com.example.tablacontenido.tokens;

public class Caracter extends Token {
    public Caracter(String token, int linea, int columnaInicio, int columnaFinal) {
        super(token, linea, columnaInicio, columnaFinal);
    }

    @Override
    public String getTipo() { return "Caracter";}
}