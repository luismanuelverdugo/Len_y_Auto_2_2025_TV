package com.example.tablacontenido;

import com.example.tablacontenido.tokens.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class AnalizadorTokens {
    private String txtCodigo;
    private int size;
    private int i;
    private int linea;
    private int columna;
    private List<Token> listaTokens;

    private static HashMap<String, String> tipoToken;
    private static HashMap<String, String> palabrasReservadas;

    static {
        tipoToken = new HashMap<>();
        palabrasReservadas = new HashMap<>();
        inicializarSimbolos();
        inicializarPalabrasReservadas();
    }

    private static void inicializarSimbolos() {
        tipoToken.put("(", "Simbolo");
        tipoToken.put(")", "Simbolo");
        tipoToken.put("{", "Simbolo");
        tipoToken.put("}", "Simbolo");
        tipoToken.put("[", "Simbolo");
        tipoToken.put("]", "Simbolo");
        tipoToken.put(";", "Simbolo");
        tipoToken.put(":", "Simbolo");
        tipoToken.put(",", "Simbolo");
        tipoToken.put(".", "Simbolo");
        tipoToken.put("+", "Simbolo");
        tipoToken.put("-", "Simbolo");
        tipoToken.put("*", "Simbolo");
        tipoToken.put("/", "Simbolo");
        tipoToken.put("%", "Simbolo");
        tipoToken.put("=", "Simbolo");
        tipoToken.put("!", "Simbolo");
        tipoToken.put("<", "Simbolo");
        tipoToken.put(">", "Simbolo");
        tipoToken.put("&", "Simbolo");
        tipoToken.put("|", "Simbolo");
        tipoToken.put("^", "Simbolo");
        tipoToken.put("~", "Simbolo");
        tipoToken.put("?", "Simbolo");
        tipoToken.put("#", "Simbolo");
    }

    private static void inicializarPalabrasReservadas(){
        palabrasReservadas.put("int", "PR");
        palabrasReservadas.put("char", "PR");
        palabrasReservadas.put("String", "PR");
        palabrasReservadas.put("short", "PR");
        palabrasReservadas.put("long", "PR");
        palabrasReservadas.put("float", "PR");
        palabrasReservadas.put("double", "PR");
        palabrasReservadas.put("void", "PR");
        palabrasReservadas.put("signed", "PR");
        palabrasReservadas.put("unsigned", "PR");
        palabrasReservadas.put("if", "PR");
        palabrasReservadas.put("else", "PR");
        palabrasReservadas.put("switch", "PR");
        palabrasReservadas.put("case", "PR");
        palabrasReservadas.put("default", "PR");
        palabrasReservadas.put("for", "PR");
        palabrasReservadas.put("while", "PR");
        palabrasReservadas.put("do", "PR");
        palabrasReservadas.put("break", "PR");
        palabrasReservadas.put("continue", "PR");
        palabrasReservadas.put("goto", "PR");
        palabrasReservadas.put("return", "PR");
        palabrasReservadas.put("auto", "PR");
        palabrasReservadas.put("register", "PR");
        palabrasReservadas.put("static", "PR");
        palabrasReservadas.put("extern", "PR");
        palabrasReservadas.put("volatile", "PR");
        palabrasReservadas.put("const", "PR");
        palabrasReservadas.put("typedef", "PR");
        palabrasReservadas.put("struct", "PR");
        palabrasReservadas.put("union", "PR");
        palabrasReservadas.put("enum", "PR");
        palabrasReservadas.put("sizeof", "PR");
        palabrasReservadas.put("iostream", "PR");
    }
    public AnalizadorTokens(String codigo) {
        this.txtCodigo = codigo;
        this.size = codigo.length();
        this.i = 0;
        this.linea = 1;
        this.columna = 0;
        this.listaTokens = new ArrayList<>();
    }

    public List<Token> analizar() {
        while (i < size) {
            char c = txtCodigo.charAt(i);
            columna++;

            if (procesarEspaciosBlanco(c)) continue;


            if (procesarComentarioLinea(c)) continue;
            if (procesarComentarioBloque(c)) continue;

            if (procesarCadena(c)) continue;
            if (procesarCaracteres(c)) continue;

            if (procesarNumero(c)) continue;


            if (procesarIdentificador(c)) continue;

            if (procesarSimbolo(c)) continue;

            if (procesarDesconocido(c)) continue;
        }

        return listaTokens;
    }

    private boolean procesarComentarioBloque(char c) {
        if (i<size - 1 && txtCodigo.charAt(i+1) == '*'){
            i += 2;
            columna += 2;

            while (i<size - 1){
                if(txtCodigo.charAt(i) == '\n'){
                    linea++;
                    columna = 0;
                }
                if (txtCodigo.charAt(i) == '*' && txtCodigo.charAt(i + 1) == '/'){
                    i += 2;
                    columna += 2;
                    break;
                }
                i++;
                columna++;
            }
            columna --;

            return true;
        }
        return false;
    }

    private boolean procesarComentarioLinea(char c) {
        if (i < size - 1 && c == '/' && txtCodigo.charAt(i+1) == '/' ){
            while (i < size && txtCodigo.charAt(i) != '\n' ){
                i++;
            }
            return true;
        }
        return false;
    }

    private boolean procesarNumero(char c) {
        if(Character.isDigit(c)){
            int colInicio = columna;
            StringBuilder sb = new StringBuilder();

            while(i<size && (Character.isDigit(txtCodigo.charAt(i)) || txtCodigo.charAt(i)=='.')){
                sb.append(txtCodigo.charAt(i));
                i++;
                columna++;

            }

            columna--;
            listaTokens.add(new Numero (sb.toString(), linea, colInicio, columna));
            return true;

        }

        return false;
    }

    private boolean procesarCaracteres(char c) {
        if( c=='\''){
            int colInicio = columna;
            StringBuilder sb = new StringBuilder();
            sb.append(c);
            i++;
            columna++;

            while (i<size){
                char ch = txtCodigo.charAt(i);
                sb.append(ch);

                if(ch== '\\' && i + 1 < size){
                    sb.append(txtCodigo.charAt(i + 1));
                    i+=2;
                    columna+=2;
                    continue;
                }

                if( ch == '\''){
                    i++;
                    columna++;
                    break;
                }

                i++;
                columna++;
            }
            columna--;
            listaTokens.add(new Caracter(sb.toString(),linea,colInicio,columna));
            return true;
        }
        return false;
    }

    private boolean procesarCadena(char c) {
        if (c== '"'){
            int colInicio = columna;
            StringBuilder sb = new StringBuilder();
            sb.append(c);
            i++;
            columna++;

            while(i < size) {
                char ch = txtCodigo.charAt(i);
                sb.append(ch);

                if (ch == '\\' && i + 1<size){
                    sb.append(txtCodigo.charAt(i+1));
                    i+=2;
                    columna += 2;
                    continue;
                }

                if (ch == '"'){
                    i++;
                    columna ++;
                    break;
                }

                i++;
                columna++;

            }

            columna --;
            listaTokens.add(new Cadena(sb.toString(),linea,colInicio,columna));
            return true;
        }
        return false;
    }

    private boolean procesarEspaciosBlanco(char c) {
        if (Character.isWhitespace(c)) {
            if (c == '\n') {
                linea++;
                columna = 0;
            }
            i++;
            return true;
        }
        return false;
    }

    private boolean procesarSimbolo(char c) {
        if (tipoToken.containsKey(String.valueOf(c))) {
            int colInicio = columna;
            String simbolo = String.valueOf(c);
            int longitudMaxima = 1;

            if (i + 3 <= size) {
                String op3 = txtCodigo.substring(i, i + 3);
                if (tipoToken.containsKey(op3)) {
                    simbolo = op3;
                    longitudMaxima = 3;
                }
            }

            if (longitudMaxima == 1 && i + 2 <= size) {
                String op2 = txtCodigo.substring(i, i + 2);
                if (tipoToken.containsKey(op2)) {
                    simbolo = op2;
                    longitudMaxima = 2;
                }
            }

            i += longitudMaxima;
            columna += longitudMaxima - 1;
            int colFinal = columna;

            listaTokens.add(new Simbolo(simbolo, linea, colInicio, colFinal));
            return true;
        }
        return false;
    }

    private boolean procesarIdentificador(char c) {
        if (Character.isLetter(c) || c == '_') {
            int colInicio = columna;
            StringBuilder sb = new StringBuilder();

            while (i < size && (Character.isLetterOrDigit(txtCodigo.charAt(i))
                    || txtCodigo.charAt(i) == '_')) {
                sb.append(txtCodigo.charAt(i));
                i++;
                columna++;
            }
            columna--;

            String palabra = sb.toString();
            Token token;

            if (palabrasReservadas.containsKey(palabra) && palabrasReservadas.get(palabra).equals("PR")) {
                token = new PalabraReservada(palabra, linea, colInicio, columna);
            } else {
                token = new Identificador(palabra, linea, colInicio, columna);

            }
            listaTokens.add(token);
            return true;


        }

        return false;

    }

    private boolean procesarDesconocido(char c) {
        listaTokens.add(new Desconocido(String.valueOf(c), linea, columna, columna));
        i++;
        return false;
    }

}