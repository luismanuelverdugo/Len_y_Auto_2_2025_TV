package com.example.tablacontenido;

import java.io.BufferedReader;
import java.io.FileReader;

public class Lector {
    private String texto;
    private int fila;
    private String codigo;
    private int columna;
/*
    public String leer(String texto ){
this.texto=texto;
this.fila=1;
this.columna=1;
    }

    public void Analizador(){
        for(char c:texto.toCharArray()){
        if(c=='/n'){
            fila ++;
            columna=1;

        }else{

        }
    }

    }*/
}
