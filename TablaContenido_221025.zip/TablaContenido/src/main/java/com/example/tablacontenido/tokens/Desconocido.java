package com.example.tablacontenido.tokens;

public class Desconocido extends Token {
    public Desconocido(String token, int linea, int columnaInicio, int columnaFinal) {
        super(token, linea, columnaInicio, columnaFinal);
    }

    @Override
    public String getTipo() { return "Desconocido";}

}
