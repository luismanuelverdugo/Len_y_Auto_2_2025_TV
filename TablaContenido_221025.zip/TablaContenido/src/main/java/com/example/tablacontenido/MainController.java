package com.example.tablacontenido;

import com.example.tablacontenido.tokens.Token;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class MainController implements Initializable {
    //public TableColumn clm_token;

    //public TableView tbl_tabla;
    @FXML
    private TableView<Token> tbl_tabla;
    @FXML
    private TableColumn<Token, String> clm_token;
    @FXML
    private TableColumn<Token, String> clm_tipo;
    @FXML
    private TableColumn<Token, Integer> clm_renglon;
    @FXML
    private TableColumn<Token, Integer> clm_clumnai;
    @FXML
    private TableColumn<Token, Integer> clm_columnaf;
    @FXML
    private Label welcomeText;
    @FXML
    private TextArea txt_codigo;


    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    public void btnCargarClick(ActionEvent actionEvent) {
        FileChooser filechooser = new FileChooser();
        filechooser.setTitle("Cargar codigo");
        filechooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Archivos de C++", "*.cpp"));
        File archivoSeleccionado = filechooser.showOpenDialog(new Stage());

        if (archivoSeleccionado != null){
            try {
                String contenido = Files.readString(archivoSeleccionado.toPath());
                txt_codigo.setText(contenido);
            }catch (IOException ex){
                ex.printStackTrace();
            }
        }
    }

    public void btnGenerarClick(ActionEvent actionEvent) {
        String codigo = txt_codigo.getText();

        AnalizadorTokens analizador = new AnalizadorTokens(codigo);
        List<Token> tokens = analizador.analizar();

        tbl_tabla.getItems().setAll(tokens);
    }

    public void initialize(URL url, ResourceBundle resourceBundle){
        clm_token.setCellValueFactory(new PropertyValueFactory<>("token"));
        clm_tipo.setCellValueFactory(new PropertyValueFactory<>("tipo"));
        clm_renglon.setCellValueFactory(new PropertyValueFactory<>("linea"));
        clm_clumnai.setCellValueFactory(new PropertyValueFactory<>("columnaInicio"));
        clm_columnaf.setCellValueFactory(new PropertyValueFactory<>("columnaFinal"));
    }
}