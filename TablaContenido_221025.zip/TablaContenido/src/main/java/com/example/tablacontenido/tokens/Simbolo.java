package com.example.tablacontenido.tokens;

import java.util.HashMap;

public class Simbolo extends Token {
    public Simbolo(String token, int linea, int columnaInicio, int columnaFinal) {
        super(token, linea, columnaInicio, columnaFinal);
    }

    @Override
    public String getTipo() { return "Símbolo";}
}
