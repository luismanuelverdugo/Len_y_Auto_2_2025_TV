package com.example.tablacontenido;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

public class HelloController {
    @FXML
    private Label welcomeText;
    @FXML
    private TextArea txt_codigo;

    private Palabra_reservada palabra_reservada;
    private Simbolo simbolo;


    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    public void btnCargarClick(ActionEvent actionEvent) {
        FileChooser filechooser = new FileChooser();
        filechooser.setTitle("Cargar codigo");
        filechooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Archivos de texto", "*.java"));
        File archivoSeleccionado = filechooser.showOpenDialog(new Stage());

        if (archivoSeleccionado != null){
            try {
                String contenido = Files.readString(archivoSeleccionado.toPath());
                txt_codigo.setText(contenido);
            }catch (IOException ex){
                ex.printStackTrace();
            }
        }
    }

    public void btnGenerarClick(ActionEvent actionEvent) {
        List<String> listaTokens = new ArrayList<>();
        String txtcodigo = txt_codigo.getText();
        int tamanio = txtcodigo.length();
        char letra;
        String palabraTemp = "";
        for(int i=0; i<tamanio; i++){
            letra = txtcodigo.charAt(i);
            if(letra == ' '){
                if(palabraTemp.length() == 0){
                    continue;
                }
                listaTokens.add(palabraTemp);
                palabraTemp = "";
                continue;
            }
            palabraTemp += letra;
        }
        //Lo siguientes son pruebas
        for(int i=0; i<listaTokens.size(); i++){
            if(palabra_reservada.getPalabrasReservadas().containsKey(listaTokens.get(i)))
            {
                //Aki ce ebalua y ce himprime
            }
                System.out.println(listaTokens.get(i));
        }
    }
}