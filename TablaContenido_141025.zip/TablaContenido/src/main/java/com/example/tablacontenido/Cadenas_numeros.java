package com.example.tablacontenido;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Cadenas_numeros {
    /*char valor;

    public void Cadenas_numeros( char valor){
        this.valor = valor;
    }

    public char esNumero(char valor) {
        char[] numeros = {1, 2, 3, 4, 5, 6, 7, 8, 9, 0};

        for (int i = 0; i < 10; i++) {
            if (valor == numeros[i]) {
                return valor;
            }
        }


    }*/


 }
