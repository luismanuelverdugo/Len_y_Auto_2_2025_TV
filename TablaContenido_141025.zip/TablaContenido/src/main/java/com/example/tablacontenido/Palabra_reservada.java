package com.example.tablacontenido;

import java.util.HashMap;

public class Palabra_reservada {

    private HashMap<String, String> palabrasReservadas = new HashMap<>();

    public void hashMapPalabrasReservadas()
    {
        palabrasReservadas.put("int", "PR");
        palabrasReservadas.put("char", "PR");
        palabrasReservadas.put("short", "PR");
        palabrasReservadas.put("long", "PR");
        palabrasReservadas.put("float", "PR");
        palabrasReservadas.put("double", "PR");
        palabrasReservadas.put("void", "PR");
        palabrasReservadas.put("signed", "PR");
        palabrasReservadas.put("unsigned", "PR");
        palabrasReservadas.put("if", "PR");
        palabrasReservadas.put("else", "PR");
        palabrasReservadas.put("switch", "PR");
        palabrasReservadas.put("case", "PR");
        palabrasReservadas.put("default", "PR");
        palabrasReservadas.put("for", "PR");
        palabrasReservadas.put("while", "PR");
        palabrasReservadas.put("do", "PR");
        palabrasReservadas.put("break", "PR");
        palabrasReservadas.put("continue", "PR");
        palabrasReservadas.put("goto", "PR");
        palabrasReservadas.put("return", "PR");
        palabrasReservadas.put("auto", "PR");
        palabrasReservadas.put("register", "PR");
        palabrasReservadas.put("static", "PR");
        palabrasReservadas.put("extern", "PR");
        palabrasReservadas.put("volatile", "PR");
        palabrasReservadas.put("const", "PR");
        palabrasReservadas.put("typedef", "PR");
        palabrasReservadas.put("struct", "PR");
        palabrasReservadas.put("union", "PR");
        palabrasReservadas.put("enum", "PR");
        palabrasReservadas.put("sizeof", "PR");
    }

    public HashMap<String, String> getPalabrasReservadas() {
        return palabrasReservadas;
    }
}
