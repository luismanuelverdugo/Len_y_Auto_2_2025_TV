package com.example.tablacontenido;

import java.util.HashMap;

public class Simbolo {

    HashMap <Character, String> simbolos = new HashMap<>();

    private void hashMapSimbolos() {
        simbolos.put('(', "Simbolo");
        simbolos.put(')', "Simbolo");
        simbolos.put('{', "Simbolo");
        simbolos.put('}', "Simbolo");
        simbolos.put('[', "Simbolo");
        simbolos.put(']', "Simbolo");
        simbolos.put(';', "Simbolo");
        simbolos.put(':', "Simbolo");
        simbolos.put(',', "Simbolo");
        simbolos.put('.', "Simbolo");
        simbolos.put('+', "Simbolo");
        simbolos.put('-', "Simbolo");
        simbolos.put('*', "Simbolo");
        simbolos.put('/', "Simbolo");
        simbolos.put('%', "Simbolo");
        simbolos.put('=', "Simbolo");
        simbolos.put('!', "Simbolo");
        simbolos.put('<', "Simbolo");
        simbolos.put('>', "Simbolo");
        simbolos.put('&', "Simbolo");
        simbolos.put('|', "Simbolo");
        simbolos.put('^', "Simbolo");
        simbolos.put('~', "Simbolo");
        simbolos.put('?', "Simbolo");
        simbolos.put('#', "Simbolo");
    }

    public HashMap<Character, String> getSimbolos() {
        return simbolos;
    }
}
