package com.example.tablacontenido;

import java.io.BufferedReader;
import java.io.FileReader;

public class Lector {
    /*
    private String codigo;
    private int columna;

    public String leer(){

    }
    FileReader f = new FileReader();

*/
}
