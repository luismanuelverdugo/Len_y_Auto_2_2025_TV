package com.example.tablacontenido.tokens;

public abstract class Token {
    protected String token;
    protected int linea;
    protected int columnaInicio;
    protected int columnaFinal;

    public Token(String token, int linea, int columnaInicio, int columnaFinal) {
        this.token = token;
        this.linea = linea;
        this.columnaInicio = columnaInicio;
        this.columnaFinal = columnaFinal;
    }

    public String getToken() { return token; }
    public int getLinea() {
        return linea;
    }
    public int getColumnaInicio() {
        return columnaInicio;
    }
    public int getColumnaFinal() {
        return columnaFinal;
    }

    public abstract String getTipo();
}


