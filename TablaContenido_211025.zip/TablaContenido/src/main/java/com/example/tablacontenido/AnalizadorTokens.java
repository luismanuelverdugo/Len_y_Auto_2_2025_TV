package com.example.tablacontenido;

import com.example.tablacontenido.tokens.Cadenas_caracteres;
import com.example.tablacontenido.tokens.Desconocido;
import com.example.tablacontenido.tokens.Simbolo;
import com.example.tablacontenido.tokens.Token;
import com.example.tablacontenido.tokens.Identificador;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class AnalizadorTokens {
    private String txtCodigo;
    private int size;
    private int i;
    private int linea;
    private int columna;
    private List<Token> listaTokens;

    private static HashMap<String, String> tipoToken;

    static {
        tipoToken = new HashMap<>();
        inicializarSimbolos();
        // inicializarPalabrasReservadas();
    }

    private static void inicializarSimbolos() {
        tipoToken.put("(", "Simbolo");
        tipoToken.put(")", "Simbolo");
        tipoToken.put("{", "Simbolo");
        tipoToken.put("}", "Simbolo");
        tipoToken.put("[", "Simbolo");
        tipoToken.put("]", "Simbolo");
        tipoToken.put(";", "Simbolo");
        tipoToken.put(":", "Simbolo");
        tipoToken.put(",", "Simbolo");
        tipoToken.put(".", "Simbolo");
        tipoToken.put("+", "Simbolo");
        tipoToken.put("-", "Simbolo");
        tipoToken.put("*", "Simbolo");
        tipoToken.put("/", "Simbolo");
        tipoToken.put("%", "Simbolo");
        tipoToken.put("=", "Simbolo");
        tipoToken.put("!", "Simbolo");
        tipoToken.put("<", "Simbolo");
        tipoToken.put(">", "Simbolo");
        tipoToken.put("&", "Simbolo");
        tipoToken.put("|", "Simbolo");
        tipoToken.put("^", "Simbolo");
        tipoToken.put("~", "Simbolo");
        tipoToken.put("?", "Simbolo");
        tipoToken.put("#", "Simbolo");
    }

    public AnalizadorTokens(String codigo) {
        this.txtCodigo = codigo;
        this.size = codigo.length();
        this.i = 0;
        this.linea = 1;
        this.columna = 0;
        this.listaTokens = new ArrayList<>();
    }

    public List<Token> analizar() {
        while (i < size) {
            char c = txtCodigo.charAt(i);
            columna++;

            if (procesarEspaciosBlanco(c)) continue;

            /*
            if (procesarComentarioLinea(c)) continue;
            if (procesarComentarioBloque(c)) continue;

            if (procesarCadena(c)) continue;
            if (procesarCaracteres(c)) continue;

            if (procesarNumero(c)) continue;

             */

            if (procesarIdentificador(c)) continue;

            if (procesarSimbolo(c)) continue;

            if (procesarDesconocido(c)) continue;
        }

        return listaTokens;
    }

    private boolean procesarEspaciosBlanco(char c) {
        if (Character.isWhitespace(c)) {
            if (c == '\n') {
                linea++;
                columna = 0;
            }
            i++;
            return true;
        }
        return false;
    }

    private boolean procesarSimbolo(char c) {
        if (tipoToken.containsKey(String.valueOf(c))) {
            int colInicio = columna;
            String simbolo = String.valueOf(c);
            int longitudMaxima = 1;

            if (i + 3 <= size) {
                String op3 = txtCodigo.substring(i, i + 3);
                if (tipoToken.containsKey(op3)) {
                    simbolo = op3;
                    longitudMaxima = 3;
                }
            }

            if (longitudMaxima == 1 && i + 2 <= size) {
                String op2 = txtCodigo.substring(i, i + 2);
                if (tipoToken.containsKey(op2)) {
                    simbolo = op2;
                    longitudMaxima = 2;
                }
            }

            i += longitudMaxima;
            columna += longitudMaxima - 1;
            int colFinal = columna;

            listaTokens.add(new Simbolo(simbolo, linea, colInicio, colFinal));
            return true;
        }
        return false;
    }

    private boolean procesarIdentificador(char c) {
        if (Character.isLetter(c) || c == '_') {
            int colInicio = columna;
            StringBuilder sb = new StringBuilder();

            while (i < size && (Character.isLetterOrDigit(txtCodigo.charAt(i))
                    || txtCodigo.charAt(i) == '_')) {
                sb.append(txtCodigo.charAt(i));
                i++;
                columna++;
            }
            columna--;

            String palabra = sb.toString();
            Token token;

            if (tipoToken.containsKey(palabra) && tipoToken.get(palabra).equals("Palabra Reservada")) {
                //token = new PalabraReservada(palabra, linea, colInicio, columna);
            } else {
                token = new Identificador(palabra, linea, colInicio, columna);
                return true;
            }


        }

        return false;

    }

    private boolean procesarDesconocido(char c) {
        listaTokens.add(new Desconocido(String.valueOf(c), linea, columna, columna));
        i++;
        return false;
    }

}