module com.example.tablacontenido {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;

    opens com.example.tablacontenido to javafx.fxml;
    exports com.example.tablacontenido;
    exports com.example.tablacontenido.tokens;
    opens com.example.tablacontenido.tokens to javafx.fxml;
}